<?php

namespace App\Http\Controllers;

class CompanyController extends Controller
{
    //
    //
    public function index()
    {
        return view('company.index');
    }
}
